"""
app.py - a small Streamlit page for trying the battery fault classifier.

    streamlit run app.py

You type in one reading (the eight numeric values from the planned packet) and
the model says which class it falls into. By default this is the model trained
on SYNTHETIC demo data, so the answer means nothing about a real battery.

This app only displays a prediction. It gives no advice and sends no commands.
"""

from __future__ import annotations

import json
import os

import joblib
import numpy as np
import pandas as pd
import sklearn
import streamlit as st
from sklearn.tree import DecisionTreeClassifier

from battery_common import (
    DEMO_TAG,
    FEATURE_COLUMNS,
    FEATURE_LABELS,
    TARGET_COLUMN,
    model_paths,
    validate_reading,
)

# Which saved model to load. Default is the synthetic demo model.
# (Later you can run:  BATTERY_MODEL_TAG=real_v1 streamlit run app.py)
MODEL_TAG = os.environ.get("BATTERY_MODEL_TAG", DEMO_TAG)

# Starting values that look like an ordinary reading. Editable in the page.
DEFAULT_VALUES = {
    "battery_voltage_v": 3.80,
    "battery_percentage": 66.0,
    "current_a": 0.05,
    "temperature_c": 31.0,
    "humidity_pct": 55.0,
    "ax_g": 0.98,
    "ay_g": 0.02,
    "az_g": 0.30,
}
STEPS = {
    "battery_voltage_v": 0.01,
    "battery_percentage": 1.0,
    "current_a": 0.01,
    "temperature_c": 1.0,
    "humidity_pct": 1.0,
    "ax_g": 0.01,
    "ay_g": 0.01,
    "az_g": 0.01,
}
CLASS_NAMES = {0: "NO FAULT FLAG (0)", 1: "FAULT FLAG (1)"}

st.set_page_config(page_title="Battery fault classifier - learning prototype", layout="centered")


# --------------------------------------------------------------------------
# Loading
# --------------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def load_bundle(tag: str, model_mtime: float, metadata_mtime: float):
    """Load the saved model and its metadata (cached; reloads if the files change)."""
    paths = model_paths(tag)
    metadata = json.loads(paths["metadata"].read_text(encoding="utf-8"))
    model = joblib.load(paths["model"])     # only ever loads from this project's models/ folder
    if not isinstance(model, DecisionTreeClassifier):
        raise ValueError("The saved model file is not the expected decision tree.")
    if metadata.get("feature_order") != FEATURE_COLUMNS:
        raise ValueError("The saved model uses a different feature order than this app. Retrain it.")
    if list(getattr(model, "feature_names_in_", FEATURE_COLUMNS)) != FEATURE_COLUMNS:
        raise ValueError("The model's stored feature names do not match this project. Retrain it.")
    return model, metadata


def show_notice(metadata: dict | None) -> None:
    """The warning that must always be visible."""
    if metadata is None or metadata.get("trained_on_synthetic", True):
        st.error(
            "**SYNTHETIC DEMO - NOT FOR REAL BATTERY MONITORING.** "
            "This model learned from made-up data. Its predictions say nothing reliable about a "
            "real battery and it has not been validated as a safety system."
        )
    else:
        st.warning(
            "**NOT VALIDATED.** This model was trained on user-supplied data whose labels this "
            "app cannot verify. It is not a validated safety system."
        )


def explain_path(model: DecisionTreeClassifier, row: pd.DataFrame) -> list[str]:
    """List the splits this input followed inside the tree (shows how the model decided)."""
    tree = model.tree_
    indicator = model.decision_path(row)
    node_ids = indicator.indices[indicator.indptr[0]:indicator.indptr[1]]
    steps = []
    for node in node_ids:
        if tree.children_left[node] == tree.children_right[node]:   # reached a leaf
            continue
        feature = FEATURE_COLUMNS[tree.feature[node]]
        value = float(row.iloc[0][feature])
        threshold = float(tree.threshold[node])
        went_left = np.float32(value) <= threshold                   # trees compare 32-bit floats
        steps.append(f"`{feature}` = {value:g}  is {'<=' if went_left else '>'}  {threshold:.3f}")
    return steps


# --------------------------------------------------------------------------
# Page
# --------------------------------------------------------------------------
st.title("Battery fault classifier")
st.caption("Learning prototype for an EV battery monitoring project")

try:
    paths = model_paths(MODEL_TAG)
except ValueError as exc:
    show_notice(None)
    st.error(f"Invalid BATTERY_MODEL_TAG: {exc}")
    st.stop()

if not (paths["model"].exists() and paths["metadata"].exists()):
    show_notice(None)
    st.error(
        f"No trained model found for tag '{MODEL_TAG}', so there is nothing to predict with yet."
    )
    st.markdown(
        "Run these two commands in a terminal, in the project folder, then reload this page:\n"
        "```\npython generate_demo_data.py\npython train_model.py\n```"
    )
    st.stop()

try:
    model, metadata = load_bundle(
        MODEL_TAG, paths["model"].stat().st_mtime, paths["metadata"].stat().st_mtime
    )
except Exception as exc:                      # damaged file, wrong version, mismatched features...
    show_notice(None)
    st.error(f"The saved model could not be loaded: {exc}")
    st.markdown("Try retraining with `python train_model.py`.")
    st.stop()

show_notice(metadata)

trained_with = metadata.get("library_versions", {}).get("scikit-learn")
if trained_with and trained_with != sklearn.__version__:
    st.warning(
        f"This model was trained with scikit-learn {trained_with}, but {sklearn.__version__} is "
        "installed here. Retrain (python train_model.py) if you see odd behaviour."
    )

st.subheader("Enter one reading")
st.write(
    "These are the eight numeric fields of the planned sensor packet. "
    "Text fields (activity, battery status) are not used by this first model."
)

with st.form("reading_form"):
    columns = st.columns(2)
    entered = {}
    for position, feature in enumerate(FEATURE_COLUMNS):
        name, unit = FEATURE_LABELS[feature]
        with columns[position % 2]:
            entered[feature] = st.number_input(
                f"{name} ({unit})",
                value=float(DEFAULT_VALUES[feature]),
                step=float(STEPS[feature]),
                format="%.3f" if feature == "current_a" else "%.2f",
                key=f"input_{feature}",
            )
    submitted = st.form_submit_button("Predict (demo)")

if submitted:
    problems = validate_reading(entered)
    if problems:
        st.error("Please fix the following before predicting:")
        for message in problems:
            st.error(message)
    else:
        row = pd.DataFrame([[entered[f] for f in FEATURE_COLUMNS]], columns=FEATURE_COLUMNS)
        predicted = int(model.predict(row)[0])
        probabilities = model.predict_proba(row)[0]
        confidence = float(probabilities[predicted])

        st.subheader("Result")
        st.caption("SYNTHETIC DEMO prediction" if metadata.get("trained_on_synthetic", True)
                   else "Prediction from a model trained on unverified user data")
        left, right = st.columns(2)
        left.metric(f"Predicted {TARGET_COLUMN}", CLASS_NAMES[predicted])
        right.metric("Model confidence (not calibrated)", f"{confidence:.0%}")
        st.write(f"Probability of class 1 (fault flag): **{probabilities[1]:.1%}**")
        st.caption(
            "The probability is the share of (class-weighted) training rows that ended up in the same "
            "leaf of the tree. It is a rough score, not a measured chance of a real fault."
        )

        st.markdown("**Values you entered**")
        shown = pd.DataFrame({
            "Feature": FEATURE_COLUMNS,
            "Value": [entered[f] for f in FEATURE_COLUMNS],
            "Unit": [FEATURE_LABELS[f][1] for f in FEATURE_COLUMNS],
        })
        st.dataframe(shown, hide_index=True, use_container_width=True)

        ranges = metadata.get("training_feature_ranges", {})
        outside = [
            f"{FEATURE_LABELS[f][0]}: {entered[f]:g} is outside the training range "
            f"{ranges[f]['min']:g} to {ranges[f]['max']:g}"
            for f in FEATURE_COLUMNS
            if f in ranges and not (ranges[f]["min"] <= entered[f] <= ranges[f]["max"])
        ]
        if outside:
            st.warning(
                "Some values lie outside the data this model was trained on, so the model is "
                "guessing beyond what it has seen:\n- " + "\n- ".join(outside)
            )

        with st.expander("How the model decided (its learned splits, not battery advice)"):
            for step in explain_path(model, row):
                st.markdown("- " + step)

with st.expander("About this model"):
    metrics = metadata.get("metrics_test", {})
    size = metadata.get("model_size", {})
    st.write(metadata.get("limitation", ""))
    st.write(
        f"Model: shallow decision tree, {size.get('tree_node_count', '?')} nodes, "
        f"depth {size.get('tree_depth', '?')}; saved file {size.get('joblib_file_bytes', '?')} bytes."
    )
    st.write(
        f"Test-set results ({'SYNTHETIC demo data' if metadata.get('trained_on_synthetic', True) else 'user data'}): "
        f"accuracy {metrics.get('accuracy', float('nan')):.3f}, "
        f"precision {metrics.get('precision_fault', float('nan')):.3f}, "
        f"recall {metrics.get('recall_fault', float('nan')):.3f}, "
        f"F1 {metrics.get('f1_fault', float('nan')):.3f}. "
        "These describe the demo data generator only."
    )
    st.write(
        "Raspberry Pi Pico status: **not verified**. Size, memory use and MicroPython "
        "compatibility have not been tested on a Pico."
    )
