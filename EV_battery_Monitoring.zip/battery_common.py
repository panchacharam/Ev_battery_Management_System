"""
battery_common.py - the single place where the whole project agrees on things.

Every other file (generate_demo_data.py, train_model.py, app.py and the notebook)
imports its feature list, target column, file paths and validation rules from
here. That way the feature order cannot silently differ between training and
prediction - a classic source of wrong results in machine-learning projects.

IMPORTANT: this is a LEARNING PROTOTYPE. The bundled data is SYNTHETIC (made up
by generate_demo_data.py). Nothing in this project has been validated on real
batteries, and it is not a safety system.
"""

from __future__ import annotations

import re
import struct
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
MODELS_DIR = PROJECT_ROOT / "models"
DEMO_CSV_PATH = DATA_DIR / "battery_demo_synthetic.csv"

# --------------------------------------------------------------------------
# Labels that mark where data came from
# --------------------------------------------------------------------------
SYNTHETIC_LABEL = "SYNTHETIC_DEMO"   # value of the `data_source` column in demo data
DATA_SOURCE_COLUMN = "data_source"
DEMO_TAG = "demo"                    # file-name tag of the demo model files

# --------------------------------------------------------------------------
# Columns
# --------------------------------------------------------------------------
# These names match the CSV header written by the ESP32 Phase 5 logger, so a
# real downloaded battery_data.csv can be dropped in later without renaming.
TIMESTAMP_COLUMN = "timestamp_ms"
TARGET_COLUMN = "overall_fault"      # 1 = fault flag set, 0 = no fault flag

# ORDER MATTERS: the model sees the features in exactly this order.
FEATURE_COLUMNS = [
    "battery_voltage_v",
    "battery_percentage",
    "current_a",
    "temperature_c",
    "humidity_pct",
    "ax_g",
    "ay_g",
    "az_g",
]

# Text columns in the packet. NOT used as features in this first model:
#   * battery_status is computed by the Pico FROM battery_voltage with fixed
#     thresholds, and overall_fault is computed on the Pico too. Feeding the
#     status in would let the model copy the Pico's own rule (target leakage)
#     instead of learning anything from the raw sensor numbers.
#   * activity (STILL/MOTION) is computed from ax, ay, az, so it adds no new
#     information.
#   * Text needs encoding (extra code and memory) - not Pico-friendly yet.
EXCLUDED_TEXT_COLUMNS = ["activity", "battery_status"]

# Planned UART packet field name -> CSV/feature column name
PACKET_FIELD_FOR_FEATURE = {
    "battery_voltage_v": "battery_voltage",
    "battery_percentage": "battery_percentage",
    "current_a": "current",
    "temperature_c": "temperature",
    "humidity_pct": "humidity",
    "ax_g": "ax",
    "ay_g": "ay",
    "az_g": "az",
}

# Human-friendly label and unit for each feature (used by the app and plots)
FEATURE_LABELS = {
    "battery_voltage_v": ("Battery voltage", "V"),
    "battery_percentage": ("Battery percentage (estimate from the prototype)", "%"),
    "current_a": ("Current", "A"),
    "temperature_c": ("Temperature", "\u00b0C"),
    "humidity_pct": ("Humidity", "%"),
    "ax_g": ("Acceleration X", "g"),
    "ay_g": ("Acceleration Y", "g"),
    "az_g": ("Acceleration Z", "g"),
}

# Physically plausible limits. They only catch obvious mistakes (wrong units,
# garbage values). They are NOT safe-operating limits for any battery.
PLAUSIBLE_RANGES = {
    "battery_voltage_v": (0.0, 30.0),
    "battery_percentage": (0.0, 100.0),
    "current_a": (-30.0, 30.0),
    "temperature_c": (-40.0, 125.0),
    "humidity_pct": (0.0, 100.0),
    "ax_g": (-16.0, 16.0),
    "ay_g": (-16.0, 16.0),
    "az_g": (-16.0, 16.0),
}

# The Pico sends -1 for temperature/humidity when the DHT11 read fails.
# That is "no reading", not a measurement, so it must never be used as data.
SENTINEL_VALUE = -1.0
SENTINEL_FEATURES = ("temperature_c", "humidity_pct")

# --------------------------------------------------------------------------
# Training settings (shared by train_model.py and the notebook)
# --------------------------------------------------------------------------
RANDOM_SEED = 42
TEST_SIZE = 0.25

# A shallow tree is small, readable, and easy to export as plain if/else rules.
# class_weight="balanced" makes the rarer class (fault) count more during
# training so the model does not just answer "no fault" every time.
TREE_PARAMS = dict(
    max_depth=4,
    min_samples_leaf=20,
    class_weight="balanced",
    random_state=RANDOM_SEED,
)

MIN_ROWS = 200            # refuse to train on fewer rows than this
MIN_CLASS_COUNT = 20      # each class needs at least this many rows
WARN_MINORITY_SHARE = 0.10


class DataValidationError(ValueError):
    """Raised with a plain-English explanation when the data is not usable."""


# --------------------------------------------------------------------------
# File naming for saved models
# --------------------------------------------------------------------------
def model_paths(tag: str) -> dict:
    """Return the three file paths for a model tag such as 'demo'."""
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", tag):
        raise ValueError(
            "Model tag may only contain letters, digits, '_' and '-' (max 40 characters)."
        )
    return {
        "model": MODELS_DIR / f"battery_fault_tree_{tag}.joblib",
        "tree_json": MODELS_DIR / f"battery_fault_tree_{tag}.json",
        "metadata": MODELS_DIR / f"model_metadata_{tag}.json",
    }


# --------------------------------------------------------------------------
# Data validation
# --------------------------------------------------------------------------
def validate_training_frame(df: pd.DataFrame):
    """
    Check a DataFrame before training. Returns (clean_frame, warnings).

    The clean frame holds ONLY the feature columns and the target, in the
    project's feature order. Nothing is silently repaired: if the data has
    blanks, sentinel values, out-of-range numbers or bad labels, this raises a
    DataValidationError that lists every problem, so you decide how to handle
    them instead of the code guessing.
    """
    required = FEATURE_COLUMNS + [TARGET_COLUMN]
    missing_cols = [c for c in required if c not in df.columns]
    if missing_cols:
        raise DataValidationError(
            "Missing required column(s): " + ", ".join(missing_cols)
            + "\nExpected columns: " + ", ".join(required)
        )
    if len(df) < MIN_ROWS:
        raise DataValidationError(
            f"Only {len(df)} rows found; at least {MIN_ROWS} are needed for a meaningful split."
        )

    work = df[required].apply(pd.to_numeric, errors="coerce")
    problems: list[str] = []
    warnings: list[str] = []

    for col in required:
        series = work[col]

        # Blank cells or text that is not a number
        n_bad = int(series.isna().sum())
        if n_bad:
            first = int(series.index[series.isna()][0]) + 2   # +2: header line, 1-based
            problems.append(
                f"'{col}': {n_bad} blank or non-numeric value(s) (first at CSV line {first}). "
                "Missing readings are not filled in automatically."
            )

        # Infinite values
        n_inf = int(np.isinf(series).sum())
        if n_inf:
            problems.append(f"'{col}': {n_inf} infinite value(s).")

    for col in SENTINEL_FEATURES:
        n_sentinel = int((work[col] == SENTINEL_VALUE).sum())
        if n_sentinel:
            problems.append(
                f"'{col}': {n_sentinel} value(s) equal to {SENTINEL_VALUE:g}. That is the sensor-error "
                "marker, not a real reading. Remove or blank those rows first (see data/README.md)."
            )

    for col in FEATURE_COLUMNS:
        lo, hi = PLAUSIBLE_RANGES[col]
        series = work[col]
        outside = (series < lo) | (series > hi)
        if col in SENTINEL_FEATURES:
            outside &= series != SENTINEL_VALUE   # already reported above
        n_out = int(outside.sum())
        if n_out:
            problems.append(
                f"'{col}': {n_out} value(s) outside the plausible range {lo:g} to {hi:g} (wrong units?)."
            )

    target = work[TARGET_COLUMN]
    bad_target = target.notna() & ~target.isin([0, 1])
    if int(bad_target.sum()):
        problems.append(f"'{TARGET_COLUMN}': {int(bad_target.sum())} value(s) that are not 0 or 1.")

    if problems:
        raise DataValidationError(
            "The data is not ready for training:\n  - " + "\n  - ".join(problems)
        )

    work[TARGET_COLUMN] = work[TARGET_COLUMN].astype(int)

    counts = work[TARGET_COLUMN].value_counts().reindex([0, 1], fill_value=0)
    for cls in (0, 1):
        if counts[cls] < MIN_CLASS_COUNT:
            raise DataValidationError(
                f"Class {cls} has only {int(counts[cls])} row(s); at least {MIN_CLASS_COUNT} are needed "
                "in each class to train and test reliably."
            )
    minority_share = counts.min() / counts.sum()
    if minority_share < WARN_MINORITY_SHARE:
        warnings.append(
            f"Strong class imbalance: the rarer class is only {minority_share:.1%} of the rows. "
            "Accuracy alone will look good even for a useless model - read precision and recall."
        )
    return work, warnings


def validate_reading(values: dict) -> list[str]:
    """
    Check ONE manually entered reading (used by the Streamlit app).
    Returns a list of plain-English error messages; an empty list means OK.
    """
    errors: list[str] = []
    for col in FEATURE_COLUMNS:
        name, unit = FEATURE_LABELS[col]
        if col not in values or values[col] is None:
            errors.append(f"{name}: no value given.")
            continue
        try:
            value = float(values[col])
        except (TypeError, ValueError):
            errors.append(f"{name}: '{values[col]}' is not a number.")
            continue
        if not np.isfinite(value):
            errors.append(f"{name}: value must be a finite number.")
            continue
        if col in SENTINEL_FEATURES and value == SENTINEL_VALUE:
            errors.append(
                f"{name}: {SENTINEL_VALUE:g} is the 'sensor read failed' marker used by the planned "
                "packet, not a real measurement. Enter a real reading instead."
            )
            continue
        lo, hi = PLAUSIBLE_RANGES[col]
        if not (lo <= value <= hi):
            errors.append(f"{name} must be between {lo:g} and {hi:g} {unit}; you entered {value:g}.")
    return errors


def check_timestamps_in_order(df: pd.DataFrame) -> None:
    """
    A time-based split needs rows in time order from ONE continuous session.
    timestamp_ms is the ESP32 uptime, so it restarts from 0 after every reboot.
    If it ever goes backwards we cannot tell which rows are older, so stop.
    """
    if TIMESTAMP_COLUMN not in df.columns:
        raise DataValidationError(f"A chronological split needs a '{TIMESTAMP_COLUMN}' column.")
    ts = pd.to_numeric(df[TIMESTAMP_COLUMN], errors="coerce")
    if ts.isna().any():
        raise DataValidationError(f"'{TIMESTAMP_COLUMN}' contains blank or non-numeric values.")
    if (ts.diff().dropna() < 0).any():
        raise DataValidationError(
            f"'{TIMESTAMP_COLUMN}' goes backwards, which usually means the ESP32 restarted. "
            "Uptime timestamps restart from 0, so the true time order is unknown. Split the data "
            "into one file per session (or add real clock times) before a time-based split."
        )


# --------------------------------------------------------------------------
# Train/test splitting
# --------------------------------------------------------------------------
def chronological_split(frame: pd.DataFrame, test_size: float = TEST_SIZE):
    """Oldest rows train, newest rows test. Use this for real time-ordered data."""
    n_test = int(round(len(frame) * test_size))
    train, test = frame.iloc[: len(frame) - n_test], frame.iloc[len(frame) - n_test:]
    for name, part in (("training", train), ("test", test)):
        if part[TARGET_COLUMN].nunique() < 2:
            raise DataValidationError(
                f"The {name} part of the time-ordered split contains only one class. "
                "Collect more data that includes both normal and fault examples."
            )
    return train, test


def split_frame(frame: pd.DataFrame, mode: str = "random"):
    """
    Split BEFORE fitting anything (prevents leakage).
      'random'        - stratified random split. Fine for the synthetic demo,
                        whose rows are independent. NOT for real time-series.
      'chronological' - oldest rows train, newest rows test.
    """
    if mode == "random":
        return train_test_split(
            frame,
            test_size=TEST_SIZE,
            stratify=frame[TARGET_COLUMN],
            random_state=RANDOM_SEED,
        )
    if mode == "chronological":
        return chronological_split(frame)
    raise ValueError(f"Unknown split mode '{mode}'.")


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------
def compute_metrics(y_true, y_pred) -> dict:
    """Accuracy, precision, recall, F1 for the FAULT class (1), and the confusion matrix."""
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_fault": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall_fault": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_fault": float(f1_score(y_true, y_pred, zero_division=0)),
        "confusion_matrix": {
            "layout": "[[true_negative, false_positive], [false_negative, true_positive]]",
            "true_negative": int(tn),
            "false_positive": int(fp),
            "false_negative": int(fn),
            "true_positive": int(tp),
        },
    }


# --------------------------------------------------------------------------
# Plain-Python version of the tree (a step toward a future edge experiment)
# --------------------------------------------------------------------------
def tree_to_dict(model, feature_names) -> dict:
    """
    Turn a fitted scikit-learn DecisionTreeClassifier into plain lists/numbers.
    The result can be saved as JSON and walked with predict_with_tree_dict()
    without scikit-learn - the idea behind a later microcontroller experiment.
    """
    t = model.tree_
    values = t.value[:, 0, :]
    probabilities = values / values.sum(axis=1, keepdims=True)
    return {
        "format": "decision-tree-arrays-v1",
        "feature_names": list(feature_names),
        "classes": [int(c) for c in model.classes_],
        "children_left": [int(x) for x in t.children_left],     # -1 marks a leaf
        "children_right": [int(x) for x in t.children_right],
        "feature": [int(x) for x in t.feature],                  # -2 marks a leaf
        "threshold": [float(x) for x in t.threshold],
        "p_class": [[float(p) for p in row] for row in probabilities],
    }


def _as_float32(x: float) -> float:
    # scikit-learn compares 32-bit floats, so do the same to get identical answers.
    return struct.unpack("f", struct.pack("f", float(x)))[0]


def predict_with_tree_dict(tree: dict, values) -> tuple[int, float]:
    """
    Walk the exported tree with ordinary Python.
    `values` must be in FEATURE_COLUMNS order and already validated
    (finite and within PLAUSIBLE_RANGES).
    Returns (predicted_class, probability_of_fault).
    """
    x = [_as_float32(v) for v in values]
    left, right = tree["children_left"], tree["children_right"]
    feature, threshold = tree["feature"], tree["threshold"]
    node = 0
    while left[node] != -1:
        node = left[node] if x[feature[node]] <= threshold[node] else right[node]
    p0, p1 = tree["p_class"][node]
    return (1 if p1 > p0 else 0), p1
