"""
generate_demo_data.py - make a clearly labelled SYNTHETIC battery dataset.

    python generate_demo_data.py

Output: data/battery_demo_synthetic.csv

=============================== READ THIS FIRST ===============================
EVERY ROW IN THE OUTPUT IS MADE UP BY THIS SCRIPT. None of it was measured from
a real battery. The relationships between the sensor numbers and the fault label
(for example "very low voltage means fault") are choices written in this file.
They are illustrations for learning, NOT evidence about how real batteries
behave. Any score a model gets on this data describes this generator, not
the real world.
===============================================================================

How the data is built
---------------------
* Rows come from named scenarios (normal use, borderline readings, a battery
  that reads as not connected, and several fault types). The scenario name is
  saved in the `scenario` column so you can always see why a row exists.
* A little random sensor noise is added so classes overlap near the edges.
* A small share of labels is flipped on purpose (LABEL_NOISE_RATE), because
  real fault labels are rarely perfect. Flipped rows are marked in
  `label_was_flipped`.
* Values are rounded to the same precision as the planned UART packet.
* `battery_percentage` is made roughly proportional to voltage because the
  prototype estimates it from voltage. It is NOT an independent measurement.
* The thresholds used for `battery_status` and `activity` copy the prototype's
  planned configuration (assumptions, for realism only).
* The random generator is seeded, so running this script twice gives the same file.

This script only describes situations. It gives no advice about what anyone
should do to a battery.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from battery_common import (
    DATA_SOURCE_COLUMN,
    DEMO_CSV_PATH,
    FEATURE_COLUMNS,
    RANDOM_SEED,
    SYNTHETIC_LABEL,
    TARGET_COLUMN,
    TIMESTAMP_COLUMN,
)

N_ROWS = 3000
LABEL_NOISE_RATE = 0.02          # share of labels deliberately flipped

# Assumed prototype thresholds (used ONLY to fill the demo text columns)
DISCONNECTED_BELOW_V = 0.5
CRITICAL_AT_OR_BELOW_V = 3.1
LOW_AT_OR_BELOW_V = 3.3
MOTION_DEVIATION_G = 0.15
PCT_EMPTY_V, PCT_FULL_V = 3.0, 4.2

# (scenario name, share of rows, label before noise)
SCENARIOS = [
    ("normal_idle",            0.45, 0),
    ("normal_load",            0.22, 0),
    ("normal_motion",          0.08, 0),
    ("borderline_normal",      0.07, 0),   # close to the fault ranges but still labelled 0
    ("disconnected_sensor",    0.03, 0),   # voltage input reads about 0 V
    ("low_voltage_fault",      0.05, 1),
    ("over_current_fault",     0.05, 1),
    ("over_temperature_fault", 0.04, 1),
    ("combined_fault",         0.01, 1),
]


def scenario_counts(n_rows: int) -> list[int]:
    """Rows per scenario; any rounding difference is absorbed by normal_idle."""
    counts = [int(round(share * n_rows)) for _, share, _ in SCENARIOS]
    counts[0] += n_rows - sum(counts)
    return counts


def make_scenario_rows(rng: np.random.Generator, name: str, n: int):
    """Return voltage, current, temperature, humidity, motion-noise arrays (before sensor noise)."""
    # Start from a "normal" operating point, then change what the scenario needs.
    v = np.clip(rng.normal(3.80, 0.22, n), 3.35, 4.20)
    i = rng.normal(0.04, 0.03, n)
    t = rng.normal(31, 4, n)
    h = np.clip(rng.normal(55, 12, n), 20, 90)
    motion = np.full(n, 0.01)

    if name == "normal_load":
        i = rng.uniform(0.20, 0.90, n)
        v = np.clip(rng.normal(3.70, 0.25, n) - 0.10 * i, 3.35, 4.20)
        t = np.clip(rng.normal(37, 5, n), 20, 52)
        motion = np.full(n, 0.02)

    elif name == "normal_motion":
        i = rng.normal(0.08, 0.05, n)
        motion = rng.uniform(0.10, 0.35, n)

    elif name == "borderline_normal":
        kind = rng.integers(0, 3, n)                       # which value sits near its limit
        v = np.where(kind == 0, rng.uniform(3.12, 3.32, n), v)
        i = np.where(kind == 1, rng.uniform(0.80, 0.99, n), i)
        t = np.where(kind == 2, rng.uniform(48, 57, n), t)

    elif name == "disconnected_sensor":
        v = np.abs(rng.normal(0.04, 0.03, n)).clip(0, 0.3)
        i = rng.normal(0.0, 0.01, n)

    elif name == "low_voltage_fault":
        v = rng.uniform(2.60, 3.11, n)

    elif name == "over_current_fault":
        magnitude = rng.uniform(1.0, 4.0, n)
        sign = np.where(rng.random(n) < 0.25, -1.0, 1.0)  # some negative (opposite direction)
        i = sign * magnitude
        v = np.clip(v - 0.10 * magnitude, 2.9, 4.20)
        t = rng.normal(40, 6, n)

    elif name == "over_temperature_fault":
        t = rng.uniform(60, 85, n)
        i = rng.uniform(0.10, 0.90, n)

    elif name == "combined_fault":
        kind = rng.integers(0, 3, n)
        low_v = (kind == 0) | (kind == 2)
        high_i = (kind == 1) | (kind == 2)
        high_t = kind <= 1
        v = np.where(low_v, rng.uniform(2.60, 3.11, n), v)
        i = np.where(high_i, rng.uniform(1.0, 3.0, n), i)
        t = np.where(high_t, rng.uniform(60, 80, n), t)

    return v, i, t, h, motion


def gravity_vectors(rng: np.random.Generator, motion_std: np.ndarray) -> np.ndarray:
    """Acceleration readings in g: about 1 g in a random mounting direction, plus movement noise."""
    direction = rng.normal(size=(len(motion_std), 3))
    direction /= np.linalg.norm(direction, axis=1, keepdims=True)
    scale = 1.0 + rng.normal(0, 0.01, size=(len(motion_std), 1))
    shake = rng.normal(0, 1, size=(len(motion_std), 3)) * motion_std[:, None]
    return np.clip(direction * scale + shake, -4, 4)


def build_dataset(rng: np.random.Generator) -> pd.DataFrame:
    pieces = []
    for (name, _share, label), n in zip(SCENARIOS, scenario_counts(N_ROWS)):
        v, i, t, h, motion = make_scenario_rows(rng, name, n)
        accel = gravity_vectors(rng, motion)
        pieces.append(pd.DataFrame({
            "v": v, "i": i, "t": t, "h": h,
            "ax": accel[:, 0], "ay": accel[:, 1], "az": accel[:, 2],
            "scenario": name, TARGET_COLUMN: label,
        }))
    raw = pd.concat(pieces, ignore_index=True)
    raw = raw.iloc[rng.permutation(len(raw))].reset_index(drop=True)     # mix the scenarios
    n = len(raw)

    # Sensor noise (applied to the measured values, after the scenario is chosen)
    v = np.clip(raw["v"] + rng.normal(0, 0.02, n), 0, None)
    i = raw["i"] + rng.normal(0, 0.02, n)
    t = raw["t"] + rng.normal(0, 0.7, n)
    h = np.clip(raw["h"] + rng.normal(0, 1.5, n), 0, 100)

    # Percentage follows voltage (as in the prototype); 0 when the input reads ~0 V
    pct = np.clip((v - PCT_EMPTY_V) / (PCT_FULL_V - PCT_EMPTY_V) * 100 + rng.normal(0, 2.5, n), 0, 100)
    pct = np.where(v < DISCONNECTED_BELOW_V, 0.0, pct)

    # Round like the planned packet: 2, 1, 3, 0, 0, 2, 2, 2 decimals
    v, pct, i = v.round(2), np.asarray(pct).round(1), i.round(3)
    t, h = np.round(t).astype(int), np.round(h).astype(int)
    ax, ay, az = raw["ax"].round(2), raw["ay"].round(2), raw["az"].round(2)

    # Text columns (kept for schema realism; NOT model features)
    magnitude = np.sqrt(ax ** 2 + ay ** 2 + az ** 2)
    activity = np.where(np.abs(magnitude - 1.0) >= MOTION_DEVIATION_G, "MOTION", "STILL")
    battery_status = np.select(
        [v < DISCONNECTED_BELOW_V, v <= CRITICAL_AT_OR_BELOW_V, v <= LOW_AT_OR_BELOW_V],
        ["DISCONNECTED", "CRITICAL", "LOW"],
        default="NORMAL",
    )

    # Labels: scenario label, with a few deliberately flipped
    flipped = rng.random(n) < LABEL_NOISE_RATE
    label = np.where(flipped, 1 - raw[TARGET_COLUMN].to_numpy(), raw[TARGET_COLUMN].to_numpy())

    df = pd.DataFrame({
        TIMESTAMP_COLUMN: (np.arange(n) + 1) * 5000,       # just a counter, 5 s apart
        "battery_voltage_v": v,
        "battery_percentage": pct,
        "current_a": i,
        "temperature_c": t,
        "humidity_pct": h,
        "ax_g": ax,
        "ay_g": ay,
        "az_g": az,
        "activity": activity,
        "battery_status": battery_status,
        TARGET_COLUMN: label.astype(int),
        DATA_SOURCE_COLUMN: SYNTHETIC_LABEL,
        "scenario": raw["scenario"],
        "label_was_flipped": flipped.astype(int),
    })
    assert all(col in df.columns for col in FEATURE_COLUMNS)
    return df


def main() -> None:
    print("=" * 70)
    print("SYNTHETIC DEMO DATA - made up by this script, NOT real battery data")
    print("=" * 70)

    rng = np.random.default_rng(RANDOM_SEED)
    df = build_dataset(rng)

    DEMO_CSV_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(DEMO_CSV_PATH, index=False)

    print(f"Saved {len(df)} rows to {DEMO_CSV_PATH}")
    print(f"Random seed: {RANDOM_SEED}   (same seed -> identical file)")
    print(f"Every row has {DATA_SOURCE_COLUMN} = {SYNTHETIC_LABEL}")
    print()
    print("Rows per scenario (label before noise in brackets):")
    label_before = {name: lab for name, _, lab in SCENARIOS}
    for name, count in df["scenario"].value_counts().items():
        print(f"  {name:<24} {count:>5}   [{label_before[name]}]")
    faults = int(df[TARGET_COLUMN].sum())
    print()
    print(f"{TARGET_COLUMN}: {len(df) - faults} normal (0), {faults} fault (1) "
          f"= {faults / len(df):.1%} fault")
    print(f"Labels deliberately flipped to mimic imperfect labelling: "
          f"{int(df['label_was_flipped'].sum())} rows")
    print()
    print("Reminder: the feature/label relationships here are illustrations, not")
    print("facts about real batteries. Next step:  python train_model.py")


if __name__ == "__main__":
    main()
